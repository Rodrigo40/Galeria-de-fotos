using Microsoft.AspNetCore.Mvc;
using PhotoGallery.Models;

namespace PhotoGallery.Controllers;

public class GalleryController : Controller
{
    private static List<PhotoModel> _photos = new();
        private readonly IWebHostEnvironment _env;

        public GalleryController(IWebHostEnvironment env)
        {
            _env = env;
        }

        public IActionResult Index() => View(_photos.OrderByDescending(p => p.UploadDate));

        public IActionResult Upload() => View();

        // [HttpPost]
        // public async Task<IActionResult> Upload(string title, string description, IFormFile image)
        // {
        //     if (image != null && image.Length > 0)
        //     {
        //         var fileName = Path.GetFileName(image.FileName);
        //         var filePath = Path.Combine(_env.WebRootPath, "uploads", fileName);

        //         using (var stream = new FileStream(filePath, FileMode.Create))
        //         {
        //             await image.CopyToAsync(stream);
        //         }

        //         _photos.Add(new PhotoModel
        //         {
        //             Id = _photos.Count + 1,
        //             FileName = fileName,
        //             Title = title,
        //             Description = description,
        //             UploadDate = DateTime.Now
        //         });

        //         return RedirectToAction("Index");
        //     }

        //     ViewBag.Error = "Por favor, selecione uma imagem.";
        //     return View();
        // }
        [HttpPost]
        public async Task<IActionResult> Upload(string title, string description, IFormFile image)
        {
            if (image != null && image.Length > 0)
            {
                // 1. Validação do tamanho do arquivo (exemplo)
                if (image.Length > 5 * 1024 * 1024) 
                {
                    ViewBag.Error = "O arquivo é muito grande. O limite é 5MB.";
                    return View();
                }

                // 2. Criação de um nome de arquivo único e seguro
                var uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(image.FileName);
                var filePath = Path.Combine(_env.WebRootPath, "uploads", uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await image.CopyToAsync(stream);
                }

                _photos.Add(new PhotoModel
                {
                    Id = _photos.Count + 1,
                    FileName = uniqueFileName, // Usando o nome único
                    Title = title,
                    Description = description,
                    UploadDate = DateTime.Now
                });

                return RedirectToAction("Index");
            }

            ViewBag.Error = "Por favor, selecione uma imagem.";
            return View();
        }
        public IActionResult View(int id)
        {
            var photo = _photos.FirstOrDefault(p => p.Id == id);
            return photo == null ? NotFound() : View(photo);
        }

        public IActionResult Delete(int id)
        {
            var photo = _photos.FirstOrDefault(p => p.Id == id);
            if (photo != null)
            {
                var path = Path.Combine(_env.WebRootPath, "uploads", photo.FileName);
                if (System.IO.File.Exists(path))
                    System.IO.File.Delete(path);

                _photos.Remove(photo);
            }

            return RedirectToAction("Index");
        }
}
