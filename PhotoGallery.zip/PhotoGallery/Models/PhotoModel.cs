using System;

namespace PhotoGallery.Models;

public class PhotoModel
{
        public int Id { get; set; }
        public string FileName { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime UploadDate { get; set; }
}
